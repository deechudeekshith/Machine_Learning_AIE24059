import pandas as pd
from sklearn.cluster import KMeans

#here you have to change the path of the dataset 

df = pd.read_csv(r"C:\Users\rdeek\OneDrive\Documents\SEM4\ML\labs\lab5\eeg_features_dataset.csv")

df = df.drop(columns=["subject", "recording"])


X_cluster = df.iloc[:, :-1]

print("Data shape used for clustering:", X_cluster.shape)

kmeans = KMeans(n_clusters=2, random_state=0, n_init="auto")
kmeans.fit(X_cluster)

print("\nCluster Labels:")
print(kmeans.labels_)

print("\nCluster Centers:")
print(kmeans.cluster_centers_)
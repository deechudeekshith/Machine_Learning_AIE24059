import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, calinski_harabasz_score, davies_bouldin_score

#here you have to change the path of the dataset 

df = pd.read_csv(r"C:\Users\rdeek\OneDrive\Documents\SEM4\ML\labs\lab5\eeg_features_dataset.csv")

# Remove non-numeric columns
df = df.drop(columns=["subject", "recording"])

# Remove target column
X_cluster = df.iloc[:, :-1]

# K-Means (k = 2)
kmeans = KMeans(n_clusters=2, random_state=42, n_init="auto")
kmeans.fit(X_cluster)

labels = kmeans.labels_

sil_score = silhouette_score(X_cluster, labels)
ch_score = calinski_harabasz_score(X_cluster, labels)
db_score = davies_bouldin_score(X_cluster, labels)

print("A5 RESULTS")
print("Silhouette Score:", sil_score)
print("Calinski-Harabasz Score:", ch_score)
print("Davies-Bouldin Index:", db_score)
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error


#here you have to change the path of the dataset 

df = pd.read_csv(r"C:\Users\rdeek\OneDrive\Documents\SEM4\ML\labs\lab5\eeg_features_dataset.csv")

print("Dataset Shape:", df.shape)
print(df.head())

df = df.drop(columns=["subject", "recording"])

X = df.iloc[:, :-1]
y = df.iloc[:, -1]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

X_train_single = X_train.iloc[:, [0]]
X_test_single = X_test.iloc[:, [0]]

print("Using Feature:", X.columns[0])

reg = LinearRegression()
reg.fit(X_train_single, y_train)

y_pred = reg.predict(X_test_single)


print("Coefficient:", reg.coef_)
print("Intercept:", reg.intercept_)
print("R2 Score:", r2_score(y_test, y_pred))
print("MSE:", mean_squared_error(y_test, y_pred))
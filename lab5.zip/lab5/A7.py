import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

#here you have to change the path of the dataset 

df = pd.read_csv(r"C:\Users\rdeek\OneDrive\Documents\SEM4\ML\labs\lab5\eeg_features_dataset.csv")

# Remove non-numeric columns
df = df.drop(columns=["subject", "recording"])

# Remove target column
X_cluster = df.iloc[:, :-1]

# A7: Elbow Method
k_values = range(2, 20)
distortions = []

for k in k_values:
    kmeans = KMeans(n_clusters=k, random_state=42, n_init="auto")
    kmeans.fit(X_cluster)
    distortions.append(kmeans.inertia_)

# Elbow Plot
plt.figure()
plt.plot(k_values, distortions)
plt.xlabel("Number of clusters (k)")
plt.ylabel("Distortion (Inertia)")
plt.title("Elbow Method for Optimal k")
plt.show()
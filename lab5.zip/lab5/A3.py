import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

#here you have to change the path of the dataset 


df = pd.read_csv(r"C:\Users\rdeek\OneDrive\Documents\SEM4\ML\labs\lab5\eeg_features_dataset.csv")

# Remove non-numeric columns
df = df.drop(columns=["subject", "recording"])


X = df.iloc[:, :-1]   # ALL features
y = df.iloc[:, -1]    # Target column


X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

print("Number of Features Used:", X.shape[1])


reg = LinearRegression()
reg.fit(X_train, y_train)


y_train_pred = reg.predict(X_train)
y_test_pred = reg.predict(X_test)


train_mse = mean_squared_error(y_train, y_train_pred)
train_rmse = np.sqrt(train_mse)
train_r2 = r2_score(y_train, y_train_pred)
train_mape = np.mean(np.abs((y_train - y_train_pred) / y_train)) * 100


test_mse = mean_squared_error(y_test, y_test_pred)
test_rmse = np.sqrt(test_mse)
test_r2 = r2_score(y_test, y_test_pred)
test_mape = np.mean(np.abs((y_test - y_test_pred) / y_test)) * 100


print("\n== A3 RESULTS (ALL FEATURES) ===")

print("\n TRAIN METRICS :")
print("MSE:", train_mse)
print("RMSE:", train_rmse)
print("MAPE:", train_mape)
print("R2:", train_r2)

print("\n TEST METRICS: ")
print("MSE:", test_mse)
print("RMSE:", test_rmse)
print("MAPE:", test_mape)
print("R2:", test_r2)
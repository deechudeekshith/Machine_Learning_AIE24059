import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, calinski_harabasz_score, davies_bouldin_score

#here you have to change the path of the dataset 

df = pd.read_csv(r"C:\Users\rdeek\OneDrive\Documents\SEM4\ML\labs\lab5\eeg_features_dataset.csv")

# Remove non-numeric columns
df = df.drop(columns=["subject", "recording"])

# Remove target column
X_cluster = df.iloc[:, :-1]


k_values = range(2, 11)

silhouette_scores = []
ch_scores = []
db_scores = []

for k in k_values:
    kmeans = KMeans(n_clusters=k, random_state=42, n_init="auto")
    kmeans.fit(X_cluster)
    labels = kmeans.labels_

    silhouette_scores.append(silhouette_score(X_cluster, labels))
    ch_scores.append(calinski_harabasz_score(X_cluster, labels))
    db_scores.append(davies_bouldin_score(X_cluster, labels))

# Plot Silhouette Score vs k
plt.figure()
plt.plot(k_values, silhouette_scores)
plt.xlabel("k")
plt.ylabel("Silhouette Score")
plt.title("Silhouette Score vs k")
plt.show()

# Plot CH Score vs k
plt.figure()
plt.plot(k_values, ch_scores)
plt.xlabel("k")
plt.ylabel("Calinski-Harabasz Score")
plt.title("CH Score vs k")
plt.show()


# Plot DB Index vs k
plt.figure()
plt.plot(k_values, db_scores)
plt.xlabel("k")
plt.ylabel("Davies-Bouldin Index")
plt.title("DB Index vs k")
plt.show()
import numpy as np

def backprop_xor_gate():
    inputs = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
    targets = np.array([[0], [1], [1], [0]])
    eta = 0.05
    
    V = np.random.uniform(-0.05, 0.05, (2, 2))
    W = np.random.uniform(-0.05, 0.05, (2, 1))
    
    for epoch in range(2000):
        total_sse = 0
        for i in range(len(inputs)):
            h_in = inputs[i] @ V
            h_out = 1 / (1 + np.exp(-h_in))
            
            o_in = h_out @ W
            o_out = 1 / (1 + np.exp(-o_in))
            
            error = targets[i] - o_out
            total_sse += np.sum(error**2)
            
            dk = o_out * (1 - o_out) * error
            dh = h_out * (1 - h_out) * (dk @ W.T)
            
            W += eta * np.outer(h_out, dk)
            V += eta * np.outer(inputs[i], dh)
            
        if total_sse <= 0.002:
            break
            
    print(f"XOR Converged in {epoch + 1} epochs")
    print(f"Final SSE: {total_sse}")

if __name__ == "__main__":
    backprop_xor_gate()
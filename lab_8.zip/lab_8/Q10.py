import numpy as np

def backprop_two_outputs():
    inputs = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
    targets = np.array([[1, 0], [0, 1], [0, 1], [1, 0]])
    eta = 0.05
    
    V = np.random.uniform(-0.05, 0.05, (2, 2))
    W = np.random.uniform(-0.05, 0.05, (2, 2))
    
    for epoch in range(2000):
        total_sse = 0
        for i in range(len(inputs)):
            h_out = 1 / (1 + np.exp(-(inputs[i] @ V)))
            o_out = 1 / (1 + np.exp(-(h_out @ W)))
            
            error = targets[i] - o_out
            total_sse += np.sum(error**2)
            
            dk = o_out * (1 - o_out) * error
            dh = h_out * (1 - h_out) * (dk @ W.T)
            
            W += eta * np.outer(h_out, dk)
            V += eta * np.outer(inputs[i], dh)
            
        if total_sse <= 0.002:
            break
            
    print(f"Two-Output Logic Converged in {epoch + 1} epochs")

if __name__ == "__main__":
    backprop_two_outputs()
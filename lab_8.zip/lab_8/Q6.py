import numpy as np

def train_customer_perceptron():
    data = np.array([
        [1, 20, 6, 2], [1, 16, 3, 6], [1, 27, 6, 2], [1, 19, 1, 2], [1, 24, 4, 2],
        [1, 22, 1, 5], [1, 15, 4, 2], [1, 18, 4, 2], [1, 21, 1, 4], [1, 16, 2, 4]])
    targets = np.array([1, 1, 1, 0, 1, 0, 1, 1, 0, 0])

    weights = np.random.randn(4) * 0.01
    lr = 0.01

    for epoch in range(1000):
        total_sse = 0
        for i in range(len(data)):
            z = np.dot(data[i], weights)
            output = 1 / (1 + np.exp(-z))
            error = targets[i] - output
            total_sse += error**2
            weights += lr * error * (output * (1 - output)) * data[i]

        if total_sse <= 0.002:
            break

    print(f"Converged in: {epoch + 1} epochs")
    print(f"Weights: {weights}")

if __name__ == "__main__":
    train_customer_perceptron()
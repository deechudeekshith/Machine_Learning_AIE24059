import numpy as np
import matplotlib.pyplot as plt

def train_and_gate():
    # Initial Weights [cite: 38]
    # W0 = bias weight, W1 & W2 = input weights
    weights = np.array([10.0, 0.2, -0.75])
    learning_rate = 0.05 # [cite: 38]
    
    # Inputs: [Bias(1), A, B] [cite: 17]
    inputs = np.array([[1, 0, 0], [1, 0, 1], [1, 1, 0], [1, 1, 1]])
    targets = np.array([0, 0, 0, 1])
    
    epoch_errors = []
    max_epochs = 1000 # [cite: 51]
    
    for epoch in range(max_epochs):
        total_sse = 0
        for i in range(len(inputs)):
            # Summation and Step Activation [cite: 39]
            y_in = np.dot(inputs[i], weights)
            prediction = 1 if y_in >= 0 else 0
            
            # Error and Update [cite: 35]
            error = targets[i] - prediction
            total_sse += error**2
            weights += learning_rate * error * inputs[i]
            
        epoch_errors.append(total_sse)
        # Convergence criteria [cite: 51]
        if total_sse <= 0.002:
            break
            
    # Output Results
    print(f"Converged in {len(epoch_errors)} epochs")
    print(f"Final Weights: {weights}")
    
    plt.plot(range(1, len(epoch_errors) + 1), epoch_errors)
    plt.title("Epochs vs SSE (AND Gate)")
    plt.xlabel("Epochs")
    plt.ylabel("Sum-Square-Error")
    plt.show()

if __name__ == "__main__":
    train_and_gate()
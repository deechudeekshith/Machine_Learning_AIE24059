from sklearn.neural_network import MLPClassifier
import numpy as np

def sklearn_mlp_logic():
    X_and = [[0, 0], [0, 1], [1, 0], [1, 1]]
    y_and = [0, 0, 0, 1]
    
    X_xor = [[0, 0], [0, 1], [1, 0], [1, 1]]
    y_xor = [0, 1, 1, 0]
    
    mlp_and = MLPClassifier(hidden_layer_sizes=(2,), activation='logistic', solver='lbfgs', max_iter=1000)
    mlp_and.fit(X_and, y_and)
    
    mlp_xor = MLPClassifier(hidden_layer_sizes=(2,), activation='logistic', solver='lbfgs', max_iter=1000)
    mlp_xor.fit(X_xor, y_xor)
    
    print(f"AND Predict: {mlp_and.predict(X_and)}")
    print(f"XOR Predict: {mlp_xor.predict(X_xor)}")

if __name__ == "__main__":
    sklearn_mlp_logic()
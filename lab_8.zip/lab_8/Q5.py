import numpy as np

def train_xor_perceptron():
    weights = np.array([10.0, 0.2, -0.75])
    learning_rate = 0.05
    inputs = np.array([[1, 0, 0], [1, 0, 1], [1, 1, 0], [1, 1, 1]])
    targets = np.array([0, 1, 1, 0])
    
    for epoch in range(1000):
        total_sse = 0
        for i in range(len(inputs)):
            y_in = np.dot(inputs[i], weights)
            prediction = 1 if y_in >= 0 else 0
            error = targets[i] - prediction
            total_sse += error**2
            weights += learning_rate * error * inputs[i]
        
        if total_sse <= 0.002:
            break
            
    print(f"Iterations: {epoch + 1}")
    print(f"Final SSE: {total_sse}")
    print(f"Final Weights: {weights}")

if __name__ == "__main__":
    train_xor_perceptron()
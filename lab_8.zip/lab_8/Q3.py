import numpy as np

def compare_activations():
    def get_prediction(y, name):
        if name == "Step": return 1 if y >= 0 else 0
        if name == "Bi-Polar": return 1 if y > 0 else (-1 if y < 0 else 0)
        if name == "Sigmoid": return 1 / (1 + np.exp(-y))
        if name == "ReLU": return max(0, y)
        return 0

    activations = ["Step", "Bi-Polar", "Sigmoid", "ReLU"]
    inputs = np.array([[1, 0, 0], [1, 0, 1], [1, 1, 0], [1, 1, 1]])
    targets = np.array([0, 0, 0, 1])
    learning_rate = 0.05

    for name in activations:
        weights = np.array([10.0, 0.2, -0.75])
        epochs = 0
        for epoch in range(1000):
            total_sse = 0
            for i in range(len(inputs)):
                y_in = np.dot(inputs[i], weights)
                pred = get_prediction(y_in, name)
                error = targets[i] - pred
                total_sse += error**2
                weights += learning_rate * error * inputs[i]
            epochs = epoch + 1
            if total_sse <= 0.002: break
        print(f"{name} Activation: Converged in {epochs} iterations")

if __name__ == "__main__":
    compare_activations()
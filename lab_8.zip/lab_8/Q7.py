import numpy as np

def compare_with_pinv():
    X = np.array([
        [1, 20, 6, 2], [1, 16, 3, 6], [1, 27, 6, 2], [1, 19, 1, 2], [1, 24, 4, 2],
        [1, 22, 1, 5], [1, 15, 4, 2], [1, 18, 4, 2], [1, 21, 1, 4], [1, 16, 2, 4]
    ])
    T = np.array([1, 1, 1, 0, 1, 0, 1, 1, 0, 0])

    weights_pinv = np.linalg.pinv(X) @ T

    print("Pseudo-Inverse Weights:")
    print(weights_pinv)

if __name__ == "__main__":
    compare_with_pinv()
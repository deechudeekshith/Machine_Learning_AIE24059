from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
import numpy as np

def train_project_mlp():
    X = np.random.rand(100, 5)
    y = np.random.randint(0, 2, 100)
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
    
    clf = MLPClassifier(hidden_layer_sizes=(10, 5), max_iter=1000, random_state=1)
    clf.fit(X_train, y_train)
    
    predictions = clf.predict(X_test)
    print("Project Data Classification Report:")
    print(classification_report(y_test, predictions))

if __name__ == "__main__":
    train_project_mlp()
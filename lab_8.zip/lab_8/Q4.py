import numpy as np
import matplotlib.pyplot as plt

def study_learning_rates():
    learning_rates = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0] # [cite: 79]
    inputs = np.array([[1, 0, 0], [1, 0, 1], [1, 1, 0], [1, 1, 1]])
    targets = np.array([0, 0, 0, 1])
    iterations = []

    for lr in learning_rates:
        weights = np.array([10.0, 0.2, -0.75])
        epoch_count = 1000
        for epoch in range(1000):
            total_sse = 0
            for i in range(len(inputs)):
                y_in = np.dot(inputs[i], weights)
                pred = 1 if y_in >= 0 else 0
                error = targets[i] - pred
                total_sse += error**2
                weights += lr * error * inputs[i]
            if total_sse <= 0.002:
                epoch_count = epoch + 1
                break
        iterations.append(epoch_count)

    plt.plot(learning_rates, iterations, marker='o')
    plt.title("Learning Rate vs Convergence Iterations")
    plt.xlabel("Learning Rate")
    plt.ylabel("Number of Epochs")
    plt.grid(True)
    plt.show()

if __name__ == "__main__":
    study_learning_rates()
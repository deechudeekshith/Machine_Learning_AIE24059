import numpy as np

def summation_unit(inputs, weights):
    """Computes the weighted sum of inputs."""
    return np.dot(inputs, weights)


def step_activation(y):
    return 1 if y >= 0 else 0

def bipolar_step_activation(y):
    if y > 0: return 1
    elif y == 0: return 0
    else: return -1

def sigmoid_activation(z):
    return 1 / (1 + np.exp(-z))

def relu_activation(z):
    return max(0, z)

def leaky_relu_activation(z, alpha=0.01):
    return z if z > 0 else alpha * z

# c) Comparator unit for Error calculation [cite: 35]
def calculate_error(target, output):
    return target - output

# Testing the modules
if __name__ == "__main__":
    test_input = np.array([1, 0.5, -0.5])
    test_weights = np.array([0.1, 0.2, 0.3])
    y = summation_unit(test_input, test_weights)
    print(f"Summation Output: {y}")
    print(f"Step Activation: {step_activation(y)}")